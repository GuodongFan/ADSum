# dialog_GUI


[{
	"id": "1",
	"titles": ["Is there a way to show sum a column at [Aug 19]", "GCP app engine [Aug 19]", "Form column default value [Aug 18]", "Change MySQL Sever", "Regarding Table creation", "adaptive column width", "deleted tables still show up in nocodb GUI"]
}, {
	"id": "2",
	"titles": ["2Is there a way to show sum a column at [Aug 19]", "2 app engine [Aug 19]", "Form column default value [Aug 18]", "Change MySQL Sever", "Regarding Table creation", "adaptive column width", "deleted tables still show up in nocodb GUI"]
}]